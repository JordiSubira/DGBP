/*
Copyright IBM Corp. 2016 All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

		 http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package main

import (
	"bytes"
	"fmt"
	"encoding/json"


	"github.com/hyperledger/fabric/core/chaincode/lib/cid"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

// SimpleChaincode example simple Chaincode implementation
type SimpleChaincode struct {
}

type User struct{
	ObjectType string `json:"docType"` //docType is used to distinguish the various types of objects in state database
	PKI string `json:"pki"`
	Name string `json:"name"`
	MSP string `json:"msp"`
	Dep string `json:"dep"`
}

type Dep struct{	
	ObjectType string `json:"docType"` //docType is used to distinguish the various types of objects in state database
	Name string `json:"name"`
	MSP string `json:"msp"`
}

type Trust struct{
	ObjectType string `json:"docType"` //docType is used to distinguish the various types of objects in state database
	//ID string `json:"id"`
	//Creator string `json:"cretor"`
	From string `json:"from"`
	To string `json:"to"`
}

// Init initializes the chaincode
func (t *SimpleChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response {

	fmt.Println("abac Init")

	//
	// Demonstrate the use of Attribute-Based Access Control (ABAC) by checking
	// to see if the caller has the "abac.init" attribute with a value of true;
	// if not, return an error.
	//

	MSPid , err := cid.GetMSPID(stub)
	if err != nil {
		return shim.Error("In CREATEUSER: Error: Failed to get MSPID")
	}
	fmt.Printf("MSPID= %s", MSPid)

	/*_, args := stub.GetFunctionAndParameters()
	var AdminOrg1, AdminOrg2 string    // Entities
	var AO1PubK, AO2PubKey int // Asset holdings

	if len(args) != 4 {
		return shim.Error("Incorrect number of arguments. Expecting 4")
	}*/

	// Initialize the chaincode
	objectType := "user"

	User1Org1 := &User{objectType,"PKIUser1Org1","User1","Org1MSP","Dep1"}
	User1Org1JSONasBytes, err := json.Marshal(User1Org1)
	if err != nil {
		return shim.Error(err.Error())
	}

	User1Org2 := &User{objectType,"PKIUser1Org2","User1","Org2MSP","Dep1"}
	User1Org2JSONasBytes, err := json.Marshal(User1Org2)
	if err != nil {
		return shim.Error(err.Error())
	}

	err = stub.PutState(User1Org1.PKI, User1Org1JSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}
	/*indexName := "msp~pki"
	mspPkiIndexKey, err := stub.CreateCompositeKey(indexName, []string{User1Org1.MSP, User1Org1.PKI})
	if err != nil {
		return shim.Error(err.Error())
	}
	value := []byte{0x00}
	stub.PutState(mspPkiIndexKey, value)*/


	err = stub.PutState(User1Org2.PKI, User1Org2JSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}
	/*mspPkiIndexKey2, err := stub.CreateCompositeKey(indexName, []string{User1Org2.MSP, User1Org2.PKI})
	if err != nil {
		return shim.Error(err.Error())
	}
	stub.PutState(mspPkiIndexKey2, value)
	}*/

	fmt.Printf("User1Org1 PKI= %s, User1Org2 PKI= %s\n", User1Org1.PKI, User1Org1.PKI)


	return shim.Success(nil)
}

func (t *SimpleChaincode) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("abac Invoke")
	function, args := stub.GetFunctionAndParameters()
	if function == "createUser" {
		// Make payment of X units from A to B
		return t.createUser(stub, args)
	} else if function == "deleteUser" {
		// Deletes an entity from its state
		return t.deleteUser(stub, args)
	} else if function == "queryUserByPKI" {
		// the old "Query" is now implemtned in invoke
		return t.queryUserByPKI(stub, args)
	} else if function == "queryUserByMSP" {
		// the old "Query" is now implemtned in invoke
		return t.queryUserByMSP(stub, args)
	} else if function == "createTrust" {
		// the old "Query" is now implemtned in invoke
		return t.createTrust(stub, args)
	} else if function == "delTrust" {
		// the old "Query" is now implemtned in invoke
		return t.delTrust(stub, args)
	} else if function == "queryTrust" {
		// the old "Query" is now implemtned in invoke
		return t.queryTrust(stub, args)
	}/* else if function == "createDep" {
		// the old "Query" is now implemtned in invoke
		return t.query(stub, args)
	}else if function == "deleteDep" {
		// the old "Query" is now implemtned in invoke
		return t.query(stub, args)
	}else if function == "queryDep" {
		// the old "Query" is now implemtned in invoke
		return t.query(stub, args)
	}else if function == "queryDepByMSP" {
		// the old "Query" is now implemtned in invoke
		return t.query(stub, args)
	}else if function == "queryTrustFrom" {
		// the old "Query" is now implemtned in invoke
		return t.query(stub, args)
	}*/



	return shim.Error("Invalid invoke function name. Expecting \"invoke\" \"delete\" \"query\"")
}

// Transaction makes payment of X units from A to B
func (t *SimpleChaincode) createUser(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var name,pki,msp,dep string    // Entities
	var err error

	objectType := "user"


	msp , err = cid.GetMSPID(stub)
	if err != nil {
		return shim.Error("In CREATEUSER: Error: Failed to get MSPID")
	}
	fmt.Printf("MSPID = %s", msp)

	if len(args) != 3 {
		return shim.Error("Incorrect number of arguments. Expecting 3")
	}

	pki = args[0]
	name = args[1]
	dep = args[2]
	

	userAsBytes, err := stub.GetState(pki)
	if err != nil {
		return shim.Error("Failed to get marble: " + err.Error())
	} else if userAsBytes != nil {
		fmt.Println("User with PKI = %s already exists: ", pki)
		return shim.Error("User with PKI already exists: " + pki)
	}

	user := &User{objectType,pki,name,msp,dep}
	userAsBytes, err = json.Marshal(user)
	if err != nil {
		return shim.Error(err.Error())
	}

	err = stub.PutState(user.PKI, userAsBytes)
	if err != nil {
		return shim.Error(err.Error())
	}
	/*indexName := "msp~pki"
	mspPkiIndexKey, err := stub.CreateCompositeKey(indexName, []string{user.MSP, user.PKI})
	if err != nil {
		return shim.Error(err.Error())
	}
	value := []byte{0x00}
	stub.PutState(mspPkiIndexKey, value)*/

	fmt.Printf("Success creating User PKI= %s, from MSP = %s\n", user.PKI, user.MSP)

	return shim.Success(nil)
}

// Deletes an entity from state
func (t *SimpleChaincode) deleteUser(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var jsonResp string
	var userJSON User
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	msp , err := cid.GetMSPID(stub)
	if err != nil {
		return shim.Error("In DELETEUSER: Error: Failed to get MSPID")
	}
	fmt.Printf("MSPID = %s", msp)

	pki := args[0]

	//Check if invoker MSP == user.MSP
	valAsbytes, err := stub.GetState(pki) //get the marble from chaincode state
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for user with PKI = " + pki + "\"}"
		return shim.Error(jsonResp)
	} else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"User with this PKI does not exist: " + pki + "\"}"
		return shim.Error(jsonResp)
	}

	err = json.Unmarshal([]byte(valAsbytes), &userJSON)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to decode JSON of user: " + pki + "\"}"
		return shim.Error(jsonResp)
	}

	if userJSON.MSP != msp {
		fmt.Printf("User MSP = %s is different from invoker MSP = %s", userJSON.MSP, msp)
		jsonResp = "{\"Error\":\"User MSP:"+ userJSON.MSP +" != invoker MSP: " + msp + "\"}"
		return shim.Error(jsonResp)
	}

	// Delete the key from the state in ledger
	err = stub.DelState(pki)
	if err != nil {
		return shim.Error("Failed to delete state")
	}
	/*indexName := "msp~pki"
	mspPkiIndexKey, err := stub.CreateCompositeKey(indexName, []string{user.MSP, pki})
	if err != nil {
		return shim.Error(err.Error())
	}
	stub.DelState(mspPkiIndexKey)*/

	return shim.Success(nil)
}

// query callback representing the query of a chaincode
func (t *SimpleChaincode) queryUserByPKI(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var pki, jsonResp string
	var err error

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting pki of the user to query")
	}

	pki = args[0]

	// Get the state from the ledger
	valAsbytes, err := stub.GetState(pki)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for user with PKI = " + pki + "\"}"
		return shim.Error(jsonResp)
	}else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"User does not exist: " + pki + "\"}"
		return shim.Error(jsonResp)
	}

	jsonResp = "{\"User\":\"" + string(valAsbytes) + "\"}"
	fmt.Printf("Query Response:%s\n", jsonResp)
	return shim.Success(valAsbytes)
}

func (t *SimpleChaincode) queryUserByMSP(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var msp string
	var err error

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting MSP to query")
	}

	mspInvoker , err := cid.GetMSPID(stub)
	if err != nil {
		return shim.Error("In DELETEUSER: Error: Failed to get MSPID")
	}
	fmt.Printf("MSPID = %s", mspInvoker)

	msp = args[0]

	queryString := fmt.Sprintf("{\"selector\":{\"docType\":\"user\",\"msp\":\"%s\"}}", msp)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(queryResults)
}

func (t *SimpleChaincode) createTrust(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var dstMSP string    // Entities
	var err error

	objectType := "trust"


	srcMSP, err := cid.GetMSPID(stub)
	if err != nil {
		return shim.Error("In CREATETRUST: Error: Failed to get MSPID")
	}
	fmt.Printf("MSPID = %s", srcMSP)

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting destination MSP")
	}

	dstMSP = args[0]
	
	//...TO BE CONTINUED: include only composite key

	indexName := "srcmsp~dstpki"
	srcMSPdstMSPIndexKey, err := stub.CreateCompositeKey(indexName, []string{srcMSP, dstMSP})
	if err != nil {
		return shim.Error(err.Error())
	}


	AsBytes, err := stub.GetState(srcMSPdstMSPIndexKey)
	if err != nil {
		return shim.Error("Failed to get trust relationship: " + err.Error())
	} else if AsBytes != nil {
		fmt.Println("Trust relationship = %s already exists: ", srcMSPdstMSPIndexKey)
		return shim.Error("Trust relationship already exists: " + srcMSPdstMSPIndexKey)
	}

	trust := &Trust{objectType,srcMSP,dstMSP}
	trustAsBytes, err := json.Marshal(trust)
	if err != nil {
		return shim.Error(err.Error())
	}

	err = stub.PutState(srcMSPdstMSPIndexKey, trustAsBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	fmt.Printf("Success creating relation from MSP = %s; to MSP = %s\n", srcMSP, dstMSP)

	return shim.Success(nil)
}

func (t *SimpleChaincode) delTrust(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var err error

	srcMSP, err := cid.GetMSPID(stub)
	if err != nil {
		return shim.Error("In DELTRUST: Error: Failed to get src MSPID")
	}
	fmt.Printf("MSPID = %s", srcMSP)

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting destination MSP")
	}

	dstMSP := args[0]

	//Check if invoker MSP == user.MSP
	indexName := "srcmsp~dstpki"
	srcMSPdstMSPIndexKey, err := stub.CreateCompositeKey(indexName, []string{srcMSP, dstMSP})
	if err != nil {
		return shim.Error(err.Error())
	}

	// Delete the key from the state in ledger
	err = stub.DelState(srcMSPdstMSPIndexKey)
	if err != nil {
		return shim.Error("Failed to delete state")
	}
	/*indexName := "msp~pki"
	mspPkiIndexKey, err := stub.CreateCompositeKey(indexName, []string{user.MSP, pki})
	if err != nil {
		return shim.Error(err.Error())
	}
	stub.DelState(mspPkiIndexKey)*/

	return shim.Success(nil)
}

func (t *SimpleChaincode) queryTrust(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var jsonResp string
	var err error

	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting src and dst MSP")
	}

	srcMSP := args[0]
	dstMSP := args[1]

	indexName := "srcmsp~dstpki"
	srcMSPdstMSPIndexKey, err := stub.CreateCompositeKey(indexName, []string{srcMSP, dstMSP})
	if err != nil {
		return shim.Error(err.Error())
	}

	// Get the state from the ledger
	valAsbytes, err := stub.GetState(srcMSPdstMSPIndexKey)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for trust = " + srcMSPdstMSPIndexKey + "\"}"
		return shim.Error(jsonResp)
	}else if valAsbytes == nil {
		jsonResp = "{\"Error\":\"Trust does not exist: " + srcMSPdstMSPIndexKey + "\"}"
		return shim.Error(jsonResp)
	}

	jsonResp = "{\"Trust\":\"" + string(valAsbytes) + "\"}"
	fmt.Printf("Query Response:%s\n", jsonResp)
	return shim.Success(valAsbytes)
}

// =========================================================================================
// getQueryResultForQueryString executes the passed in query string.
// Result set is built and returned as a byte array containing the JSON results.
// =========================================================================================
func getQueryResultForQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	fmt.Printf("- getQueryResultForQueryString queryString:\n%s\n", queryString)

	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

	return buffer.Bytes(), nil
}

func main() {
	err := shim.Start(new(SimpleChaincode))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode: %s", err)
	}
}